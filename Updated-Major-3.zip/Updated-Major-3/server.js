const express = require("express")
const cookieParser = require("cookie-parser")
const session = require("express-session")
var multer  = require('multer')
var upload=multer({dest:'images/'})
//images
var MongoStore=require('connect-mongo')(session)
const bodyParser = require("body-parser")
const path= require ("path");
const mongo= require("mongoose");
const cors=require("cors")


var db= mongo.connect("mongodb://127.0.0.1:27017/Olxdb",function(err,response){
    if(err){
        console.log(err)
    }
    else{
        console.log("connected to"+db,"+",response);
    }
})


var app=new express();
// app.use(cors({origin:/SaveUser/,methods:["GET","POST"]}))
app.use(cors())
app.use(cookieParser("mysecretkey"))
app.use(session({
// store:new MongoStore({"db":"Olxdb","host":"localhost","port":"27017","collection":"sessions"}),
// cookie:{maxAge:50*1000},
// secret:'IGATEKarthik',
// resave:true,
// saveUninitialized:true
}))
app.use(bodyParser())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))

app.use(function (req,res,next){
    res.setHeader("Access-Control-Allow-Origin","http://localhost:4200")
    res.setHeader("Access-Control-Allow-Methods","GET,POST,OPTIONS,PUT,DELETE,PATCH")
    res.setHeader("Access-Control-Allow-Headers","X-Requested-With,content-type")
    res.setHeader("Access-Control-Allow-Credentials",true)

    next();
});

var Schema=mongo.Schema;


var UsersData=new Schema({
    name:{type:String},
    email:{type:String},
    username:{type:String},
    password:{type:String},
    repassword:{type:String},
})
 
var PostData=mongo.Schema({
    user:{type:String},
    postName:{type:String},
    postPrice:{type:Number},
    postDes:{type:String},
    email:{type:String},
    category:{type:String},
    image:{data:Buffer, contentType:String}

})

// var model= mongo.model("users",UsersSchema,"users");  data:Buffer, contentType:String
var model=mongo.model("usersdata",UsersData,"usersdata")
var model2=mongo.model("postdata",PostData,"postdata")

// saving users registered data

app.post("/api/SaveUser",function(req,res){
    var mod=new model(req.body);
    mod.save(function(err,data){
        if(err){
            res.send({data:""+err})
        }
        else{
            res.send({data:"User Data Registerd Successfully"})
        }
    })
}) 


// saving Posted data


app.post("/api/postData",upload.single('image'),(req,res)=>{
    var pod=new model2(req.body,req.file)
    if(req.body.mode=="Save"){
        pod.save((err,data)=>{
            if(err){
                res.send({data:""+err})
            }
            else{
                res.send({data:"Post saved successfully"})
    
            }
        })
    }
    else{
        model2.findByIdAndUpdate(req.body.id,{postName:req.body.postName,postPrice:req.body.postPrice,postDes:req.body.postDes,category:req.body.category},
            function(err,data){
                if(err){
                    res.send(err)
                }
                else{
                    res.send({data:"recorde ha supdated"})
                }
            }
            )

    }
    
})

//Retrieving users registerd data from database 

app.get("/api/getUser",function(req,res){
    model.find({},function(err,data){
        if(err){
            res.send(err)
        }
        else
        {
            console.log("User data retrieved successfully")
            res.send(data)

        }
    })
});

//Retrieving users posted data from database 

app.get("/api/getPosts",function(req,res){
    model2.find({},(err,data)=>{
        if(err){
            res.send(err)
        }
        else{
            console.log("Posts retrieved successfully")
            res.send(data)
        }
    })
})


app.post("/api/deletePost",function(req,res){
    model2.remove({_id:req.body.id},function(err){
        if(err){
            res.send(err);
        }
        else{
            res.send({data:"Record has been Deleted"})
        }
    })
})
// app.get("/api/getdescription",function(req,res){
//     console.log("BOdy "+req.body)
//     console.log("Id "+req.body.id)
//     model2.findOne({_id:req.body.id},function(err,data){
//         if(err){
//             res.send({data:"error is "+err});
//         }
//         else{
//             res.send({data:"Id is retrieved"})
//         }
//     })
// })
app.listen(8080,function(){
    console.log("yo  listen   8080")
})
