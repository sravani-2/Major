export class Post {
    id:number;
    user:string;
    postName : string;
    postPrice : number;
    postDes : string;
    image:string;
    category:string
}
