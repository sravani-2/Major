import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-category',
  templateUrl: './app-category.component.html',
  styleUrls: ['./app-category.component.css']
})
export class AppCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
